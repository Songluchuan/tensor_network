Learn to select cutting planes.
