# Public vehicles for future urban transportation. 
# IEEE transactions on intelligent transportation systems, 17(12), 3344-3353, 2016.
# Zhu, M., Liu, X. Y., Tang, F., Qiu, M., Shen, R., Shu, W., & Wu, M. Y.
