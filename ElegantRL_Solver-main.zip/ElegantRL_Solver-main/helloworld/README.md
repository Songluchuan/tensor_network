## Code contributions:

+ Ming Zhu: TSP, 3SAT, MILP;

+ Shixun Wu: Graph Maxcut, Knapsack;

+ Zeliang Zhang: Vehicle routing, Vertex cover； GA and Greedy algorithms.

