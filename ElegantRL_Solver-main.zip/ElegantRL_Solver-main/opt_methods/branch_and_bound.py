# Rereference:  A GPU Implementation to Solve the Combinatorial Optimization Problems
# https://www.nvidia.com/en-us/on-demand/session/gtcspring21-s31115/
